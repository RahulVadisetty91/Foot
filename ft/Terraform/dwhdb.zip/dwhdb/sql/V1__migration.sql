CREATE TABLE employee 
( id number(5) PRIMARY KEY, 
name char(20) 
);